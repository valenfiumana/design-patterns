package mesas;

public interface IMovie {
    public String getMovie(String movieName) throws MovieException;
}
