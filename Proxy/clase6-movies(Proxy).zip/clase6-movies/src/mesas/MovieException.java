package mesas;

public class MovieException extends Exception{
    public MovieException(String message){
        super(message);
    }
}
